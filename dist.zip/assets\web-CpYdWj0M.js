import{W as n}from"./index-Bk9UiXPC.js";import"./ui-DLr64hW7.js";import"./vendor--0RGCJ5T.js";class t extends n{async show(e){}async hide(e){}}export{t as SplashScreenWeb};
